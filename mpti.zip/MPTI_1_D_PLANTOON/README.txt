Akun Github : https://github.com/arivle/plantown
Akun Freedcamp : https://freedcamp.com/Ghiffaris_Work_Proje_NYm/Kelompok_1D_PPL_awO/todos

sumber : http://tekno.kompas.com/read/2016/04/14/09062057/Ini.Dia.Daftar.Gaji.Pekerja.TI.di.Indonesia
https://www.upwork.com/o/jobs/browse/skill/network-programming/
https://www.upwork.com/o/jobs/browse/skill/game-design/
https://www.sokanu.com/careers/computer-programmer/salary/
